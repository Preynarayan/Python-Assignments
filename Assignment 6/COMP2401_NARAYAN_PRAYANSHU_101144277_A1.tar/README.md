Name: Prayanshu Narayan S# 101144277

Description of program:
This program is meant for the Carleton University Ghost hunting society. It
prompts the user for pairwise data which represents data collected during a ghost hunt
and prints this data in a nice way. The progam also checks to see if the rooms are valid or not. 

Files and purpose;
README.md: this file. 
a1-posted.c: Program file in C. 


Instructions for compiling the program:
type " gcc -Wall -o a1-posted -std=c11 a1-posted.c" 

Instructions for running the program:
type "./a1-posted"
Then follow the prompts in the terminal

Can also use a txt file for input and output like this:
type: "./a1-posted < testcases.txt > testout.txt"




Instructions for how to use the program once it is running:
Enter Room ID and EMF value until "-1 -1" are entered. 
