#include <stdio.h>          // Including stdio gives us access to printf() and scanf()

#include <stdlib.h>		//Including string gives us access to exit()

#define MAX_SIZE  50001       // Maximum number of elements in any array
#define C_OK             0	// Success flag
#define C_ERR_ARR_FULL  -1	// Error code for array is full
#define C_ERR_BAD_EMF   -2	// Error code for an invalid emf_values value
#define C_ERR_BAD_RID   -3	// Error code for an invalid Room ID value


/* Function: print_data
---------------------------
Purpose:
Prints the Room ID and EMF values using printf() from the standard library and prints the size of the arrays

Example:
Room ID     EMF   
-------   -----
384789     4.57
385678     4.68
386789     4.79
-------   -----
Total numbers of entries: 3

@param int room_ids: Identification numbers for a room
@param float emf_value: Electromagnetic Field value for the matching room
@param int size: size of the arrays

*/
int print_data(int room_ids[], float emf_values[], int size){
	printf("Room ID     EMF   \n");
	printf("-------   -----\n");
	
	for(int i = 0; i < size; i++){
		printf("%d %8.2f\n",room_ids[i], emf_values[i] );
	}

	printf("-------   -----\n");
	printf("Total numbers of entries: %d\n", size);
	printf(" \n");

return 0;
}

/* Function: is_valid_room_id
---------------------------
Purpose:
Check to see if the Room ID is between 350000 and 400000.

@param int room_ids: Identification numbers for a room
Returns: 0 if fail and 1 if pass
*/
int is_valid_room_id(int room_ids){
	if((room_ids >= 350000) && (room_ids <=400000)){
		return 1;
	} else{
		return 0;
		}
}

/* Function: is_valid_emf_values
---------------------------
Purpose:
Check to see if the EMF value is between 350000 and 400000.

@param float room_ids: Identification numbers for a room
Returns: 0 if fail and 1 if pass

*/
int is_valid_emf_values(float emf_values){
	if((emf_values >= 0.0 ) && (emf_values <=5.0)){
		return 1;
	} else{
		return 0;}
}

/* Function: get_data
---------------------------
Purpose:
Collects the Room ID and EMF values using scanf() from the standard library.
Then uses the helper functions is_valid_emf_values and is_valid_room_id to add
only the valid values the array. Invalid entries such as a Room ID lower 
than 350000 is not added and an error message is outputed. 


Type "-1 -1" to quit 


@param int room_ids: Identification numbers for a room
@param float emf_value: Electromagnetic Field for the room

return: return the size of the array.

*/
int get_data(int room_ids[MAX_SIZE], float emf_values[MAX_SIZE]){
	// variable declarations 

	float emfValue;
	int roomID;
	int i = 0;
	
	// Keep promting user to input numbers until "-1 -1"
	do{
		printf("Please enter a Room ID and an EMF value (-1 -1 to quit): \n");

		scanf("%d %f",&roomID,&emfValue);
		
		
		// check to see if the two numbers are -1  and -1
		if((roomID == -1 ) && (emfValue == -1)){
			printf("Thanks for entering data! :)\n");
			break;
		}

		
		// if the are valid
		if((is_valid_room_id(roomID) == 0)|| (is_valid_emf_values(emfValue) == 0)){

			if(is_valid_emf_values(emfValue) == 0){
				printf("Invalid Entry EMF: %f Try again\n", emfValue);
				

			}

			if(is_valid_room_id(roomID) == 0){
				printf("Invalid Entry Room ID: %d Try again\n", roomID);

			} 
			if((is_valid_room_id(roomID) == 0)&& (is_valid_emf_values(emfValue) == 0)){
				printf("Invalid Entry Room ID: %d and EMF: %f  Try again\n", roomID, emfValue );
			}
			continue;
			
		}
		// if the array is full then quit the program. 
		//I do not know why. 
		//I feel like if the arrays are full then I should stop prompting the users.
		if( i == (50000)){
			printf("Array is FULL ");
			
			exit(0);
		
		} 
		room_ids[i] = roomID;
		emf_values[i] = emfValue;
		
		i++;

	}while((roomID != -1) && (emfValue != -1));
	



	

	return i;
}

/* Function: remove_values_under
---------------------------
Purpose:
Removes EMF values and their corresponding Room ID from the array if they are below 
the threshold.
If no entries remain then a message is displayed

@param float threshold: lower threshold for EMF value
@param int room_ids: Identification numbers for a room
@param float emf_value: Electromagnetic Field value for the matching room
@param int size: size of the arrays

*/
int remove_values_under(float threshold, int room_ids[], float emf_values[], int size){
	int currInt = 0;
	for(int i = 0; i < size; i++){

		if(emf_values[i]>= threshold){
			emf_values[currInt] = emf_values[i];
			room_ids[currInt] = room_ids[i];
			currInt++;
		}
	}

	if(currInt == 0){
		printf("No entries left after removing values under threshold.");
		exit(0);
	}

	return currInt;
}

/* Function: sort
---------------------------
Purpose:
Uses bubble sort to sort the arrays from lowest room number to highest 

Example:
Room ID     EMF   
-------   -----
386789     4.79
384789     4.57
385678     4.68
-------   -----
Total numbers of entries: 3

sort(room_ids,emf_values,size)

Room ID     EMF  
-------   -----
384789     4.57
385678     4.68
386789     4.79
-------   -----
Total numbers of entries: 3


@param int room_ids: Identification numbers for a room
@param float emf_value: Electromagnetic Field value for the matching room
@param sint ize: size of the arrays

*/
void sort(int room_ids[], float emf_values[], int size){

	int tempRID;
	float tempEMF;
	int swap = 0; 

	do{
		swap = 0; 
		for(int i = 1; i <size; i++){
			if(room_ids[i-1] > room_ids[i]){
				tempRID = room_ids[i-1];
				tempEMF = emf_values[i-1];

				room_ids[i-1] = room_ids[i];
				emf_values[i-1] = emf_values[i];

				room_ids[i] = tempRID;
				emf_values[i] = tempEMF;
				swap = 1;

			}
			
		}
		


	} while(swap);



}
// Main funtion
int main()
{
	
	int roomID[MAX_SIZE];
	float EMF[MAX_SIZE];
	// get the data and store its size  to sizeArr
	int sizeArr = get_data(roomID, EMF);
	
	// exits the program if the arrays are empty
	if(sizeArr == 0){
		printf("Arrays entered are empty\n");
		exit(0);
	}

	// print Data
	print_data(roomID, EMF, sizeArr);
	printf(" \n");

	// Sort Data
	sort(roomID, EMF, sizeArr);

	
	// remove data below the threshold of 4.5 and store its size  to sizeArr
	sizeArr = remove_values_under(4.5, roomID, EMF, sizeArr);


	printf(" \n");

	printf("Filterd Data!!!\n");
	
	print_data(roomID, EMF, sizeArr);
	 
	
  return 0;
}
