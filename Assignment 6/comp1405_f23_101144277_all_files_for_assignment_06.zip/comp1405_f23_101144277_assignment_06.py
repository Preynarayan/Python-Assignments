#Assignment 6 by Prayanshu Narayan S#101144277
from random import *
from typing import List


#Function to create a list of random numbers
#param: none
#return: list of random numbers
def CreateList()-> List[int]:
    list1 = []
    rand = randint(1, 10)
    while True:
        list1.append(rand)
        print(f"List is {list1}")
        if(input("Do you want to continue?").upper() == "YES"):
            break
        rand = randint(1, 10)
    return list1

#function to find a value in a list and remove it 3 times
#param: list of random numbers
#return: list of random numbers
def FindValue(list1: List[int]) -> List[int]:
    value = int(input("Enter a value to find: "))
    
    for _ in range(3):
        range1 = len(list1)
        for i in range(range1):
            if(list1[i] == value):
                list1.pop(i)
                break
#placeholder function
#param: list of random numbers
#return: list of random numbers
def placeholder(list1: List[int]) -> List[int]:
    return list1      

    
#main function
#param: none
#return: none
def main():
    mainList = []
    mainList = CreateList()
    FindValue(mainList)
    print(placeholder(mainList))
    
main()
        
    